# Paper Trader – 5 Bots, je 100 € virtuell

Ausschließlich Paper Trading. Keine Einzahlungen, keine Broker-Orders, keine geheimen Schlüssel im Frontend.

## Architektur

```
Kraken Public API (echte BTC/ETH/SOL-EUR-Daten, kein Key nötig)
        │  nur geschlossene Kerzen + aktuelles Orderbuch
        ▼
Supabase Edge Function `trading-engine`  ◄── pg_cron, jede Minute (läuft in der Cloud)
        │  Strategien → Risikoprüfung → Ausführungs-Simulation
        ▼
Postgres: bots, positions, trades, market_snapshots, equity_history, decisions, error_logs
        │  Row Level Security: öffentlich nur Lesen
        ▼
web/index.html (statisch, mobile-first) – liest mit dem Anon-Key
```

Datenquelle austauschen: neue Klasse, die `MarketDataProvider` implementiert (`getClosedCandles`, `getOrderBook`), und `provider` in `index.ts` ersetzen.

## Realismus der Simulation

- Ausführung durch Abarbeiten des echten Orderbuchs zum Entscheidungszeitpunkt (Spread + Markttiefe = Slippage), plus 0,05 % Latenz-Aufschlag
- Gebühr 0,40 % pro Seite (Kraken-Taker, Standardstufe)
- Max. 10 % der sichtbaren Orderbuch-Tiefe pro Order, sonst Teilausführung
- Strategien sehen nur abgeschlossene Kerzen; keine rückwirkenden Trades
- Stop-Loss/Take-Profit werden jede Minute geprüft und zum dann aktuellen Geldkurs ausgeführt (Gaps führen also zu schlechteren Kursen – wie in echt)
- Nur Long-Positionen (Spot), kein Hebel

## Risikoregeln (alle Bots)

- Positionsgröße = Risiko % × aktueller Kontowert ÷ Stop-Abstand, gedeckelt durch max. Positionsanteil und verfügbares Cash
- Nach Verlusten sinkt der Kontowert → Positionen werden automatisch kleiner (kein Martingale)
- Verlustlimit bezogen auf 100 € Startkapital → Bot wird PAUSIERT und Positionen werden geschlossen
- Aggressiv: Abkühlphase von 60 Min. nach 2 Verlusten in Folge
- Die 1.000-€-Challenge wird von der Engine nicht gelesen und beeinflusst keine Entscheidung

## Status

Eingerichtet im separaten Supabase-Projekt „Paper Trader“ (ref `meexklgjnfogrobnmyxg`, Frankfurt). Tabellen mit Präfix `pt_`, Engine `trading-engine`, Cron jede Minute. Das Cron-Secret liegt in `pt_secrets` (ohne öffentliche Leserechte). Nur noch `web/index.html` hosten.

## Einrichtung von Grund auf (falls neu aufgesetzt)

1. Supabase-Projekt anlegen (Free Tier reicht zum Start).
2. Supabase CLI installieren, dann im Ordner:
   ```bash
   supabase link --project-ref <PROJECT_REF>
   supabase db push
   supabase secrets set CRON_SECRET=<langer-zufallswert>
   supabase functions deploy trading-engine --no-verify-jwt
   ```
   (Der Aufruf ist über `CRON_SECRET` geschützt; `SUPABASE_URL` und `SUPABASE_SERVICE_ROLE_KEY` setzt Supabase automatisch.)
3. `supabase/setup_cron.sql` öffnen, `<PROJECT_REF>` und `<CRON_SECRET>` ersetzen, im SQL-Editor ausführen.
4. In `web/index.html` `SUPABASE_URL` und den **anon public** Key eintragen (niemals den Service-Role-Key).
5. `web/index.html` statisch hosten (Netlify Drop, Vercel, GitHub Pages, Cloudflare Pages). Auf dem iPhone: Teilen → „Zum Home-Bildschirm“.

Prüfen: Tabelle `market_snapshots` sollte jede Minute neue Zeilen bekommen, `decisions` alle 5 bzw. 15 Minuten. Fehler stehen in `error_logs` und im Dashboard-Kopf.

## Bot zurücksetzen / Pause aufheben

```sql
update bots set status='AKTIV', paused_reason=null where id='trend';
```
Kompletter Neustart eines Bots: seine Zeilen in trades, positions, decisions, equity_history löschen und `cash`, `equity`, `peak_equity` auf 100, `max_drawdown` auf 0, `state` auf `'{}'` setzen.

## Was diese Version bewusst nicht ist

Kein Backtest und keine Performance-Versprechen: Ergebnisse entstehen erst mit der Zeit aus Live-Daten. Paper-Trading-Ergebnisse lassen sich nicht 1:1 auf echtes Geld übertragen.
