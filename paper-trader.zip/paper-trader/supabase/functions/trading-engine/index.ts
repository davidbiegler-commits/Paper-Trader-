// Paper-Trading-Engine (Supabase Edge Function, Deno)
// Läuft serverseitig, per pg_cron jede Minute aufgerufen. Ausschließlich virtuelles Geld.
// Keine Broker-Orders, keine echten Einzahlungen.

import { createClient, SupabaseClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

// ======================= Konfiguration =======================
const ASSETS = [
  { symbol: "BTC/EUR", pair: "XBTEUR" },
  { symbol: "ETH/EUR", pair: "ETHEUR" },
  { symbol: "SOL/EUR", pair: "SOLEUR" },
];
const FEE_RATE = 0.004;          // Taker-Gebühr 0,40 % (Kraken-Standardstufe, konservativ)
const LATENCY_SLIPPAGE = 0.0005; // +0,05 % Aufschlag für Verzögerung zwischen Entscheidung und Ausführung
const MAX_BOOK_SHARE = 0.10;     // max. 10 % der sichtbaren Orderbuch-Tiefe pro Order
const MIN_ORDER_EUR = 5;         // kleinere Orders werden nicht ausgeführt
const CANDLES_NEEDED = 210;

// ======================= Datenquelle (austauschbar) =======================
interface Candle { t: number; o: number; h: number; l: number; c: number; v: number }
interface Level { price: number; qty: number }
interface OrderBook { bids: Level[]; asks: Level[]; ts: number }

interface MarketDataProvider {
  name: string;
  /** Nur abgeschlossene Kerzen – die laufende Kerze wird nie verwendet (kein Blick in die Zukunft). */
  getClosedCandles(pair: string, intervalMin: number): Promise<Candle[]>;
  getOrderBook(pair: string, depth: number): Promise<OrderBook>;
}

class KrakenProvider implements MarketDataProvider {
  name = "kraken";
  private base = "https://api.kraken.com/0/public";

  private async call(path: string) {
    const r = await fetch(this.base + path, { headers: { "User-Agent": "paper-trader/1.0" } });
    if (!r.ok) throw new Error(`Kraken HTTP ${r.status} bei ${path}`);
    const j = await r.json();
    if (j.error?.length) throw new Error(`Kraken: ${j.error.join(", ")}`);
    return j.result;
  }

  async getClosedCandles(pair: string, intervalMin: number): Promise<Candle[]> {
    const res = await this.call(`/OHLC?pair=${pair}&interval=${intervalMin}`);
    const key = Object.keys(res).find((k) => k !== "last")!;
    const now = Date.now();
    // Kraken: [time, open, high, low, close, vwap, volume, count]
    return (res[key] as unknown[][])
      .map((r) => ({ t: Number(r[0]) * 1000, o: Number(r[1]), h: Number(r[2]), l: Number(r[3]), c: Number(r[4]), v: Number(r[6]) }))
      .filter((c) => c.t + intervalMin * 60_000 <= now); // nur geschlossene Kerzen
  }

  async getOrderBook(pair: string, depth: number): Promise<OrderBook> {
    const res = await this.call(`/Depth?pair=${pair}&count=${depth}`);
    const b = res[Object.keys(res)[0]];
    const map = (x: string[]) => ({ price: +x[0], qty: +x[1] });
    return { bids: b.bids.map(map), asks: b.asks.map(map), ts: Date.now() };
  }
}

const provider: MarketDataProvider = new KrakenProvider();

// ======================= Indikatoren =======================
const lastOf = <T>(a: T[]) => a[a.length - 1];
const mean = (a: number[]) => a.reduce((s, x) => s + x, 0) / a.length;

function emaSeries(v: number[], p: number): number[] {
  const out: number[] = new Array(v.length).fill(NaN);
  if (v.length < p) return out;
  const k = 2 / (p + 1);
  let e = mean(v.slice(0, p));
  out[p - 1] = e;
  for (let i = p; i < v.length; i++) { e = v[i] * k + e * (1 - k); out[i] = e; }
  return out;
}
function sma(v: number[], p: number) { return mean(v.slice(-p)); }
function stdev(v: number[], p: number) {
  const s = v.slice(-p), m = mean(s);
  return Math.sqrt(mean(s.map((x) => (x - m) ** 2)));
}
function rsi(v: number[], p = 14) {
  let g = 0, l = 0;
  for (let i = 1; i <= p; i++) { const d = v[i] - v[i - 1]; if (d > 0) g += d; else l -= d; }
  g /= p; l /= p;
  for (let i = p + 1; i < v.length; i++) {
    const d = v[i] - v[i - 1];
    g = (g * (p - 1) + Math.max(d, 0)) / p;
    l = (l * (p - 1) + Math.max(-d, 0)) / p;
  }
  return l === 0 ? 100 : 100 - 100 / (1 + g / l);
}
function atrSeries(c: Candle[], p = 14): number[] {
  const tr = c.map((x, i) => i === 0 ? x.h - x.l :
    Math.max(x.h - x.l, Math.abs(x.h - c[i - 1].c), Math.abs(x.l - c[i - 1].c)));
  const out: number[] = new Array(c.length).fill(NaN);
  let a = mean(tr.slice(0, p)); out[p - 1] = a;
  for (let i = p; i < tr.length; i++) { a = (a * (p - 1) + tr[i]) / p; out[i] = a; }
  return out;
}
function macd(v: number[]) {
  const e12 = emaSeries(v, 12), e26 = emaSeries(v, 26);
  const line = v.map((_, i) => e12[i] - e26[i]).filter((x) => !isNaN(x));
  const sig = emaSeries(line, 9);
  const hist = line.map((x, i) => x - sig[i]);
  return { hist: lastOf(hist), histPrev: hist[hist.length - 2] };
}
function obvSlope(c: Candle[], n = 20) {
  let obv = 0; const s: number[] = [];
  for (let i = 1; i < c.length; i++) {
    obv += c[i].c > c[i - 1].c ? c[i].v : c[i].c < c[i - 1].c ? -c[i].v : 0;
    s.push(obv);
  }
  return lastOf(s) - s[s.length - 1 - n];
}
const r2 = (x: number, d = 2) => Math.round(x * 10 ** d) / 10 ** d;

// ======================= Strategien =======================
type Action = "KAUF" | "HALTEN" | "VERKAUF";
interface Signal { action: Action; reason: string; signals: Record<string, unknown>; stopLoss?: number; takeProfit?: number }
interface Ctx { candles: Candle[]; cfg: Record<string, number>; hasPosition: boolean }

function base(ctx: Ctx) {
  const closes = ctx.candles.map((c) => c.c);
  const atrS = atrSeries(ctx.candles);
  return { closes, close: lastOf(closes), atr: lastOf(atrS), atrS };
}
const hold = (reason: string, signals: Record<string, unknown>): Signal => ({ action: "HALTEN", reason, signals });

const strategies: Record<string, (ctx: Ctx) => Signal> = {
  trend(ctx) {
    const { closes, close, atr } = base(ctx);
    const e20 = lastOf(emaSeries(closes, 20)), e50 = lastOf(emaSeries(closes, 50));
    const m = macd(closes);
    const roc = (close / closes[closes.length - 11] - 1) * 100;
    const s = { ema20: r2(e20), ema50: r2(e50), macdHist: r2(m.hist, 4), roc10: r2(roc) };
    if (ctx.hasPosition) {
      if (e20 < e50) return { action: "VERKAUF", reason: "Trend gebrochen: EMA 20 unter EMA 50.", signals: s };
      return hold("Trend intakt, Position wird gehalten.", s);
    }
    if (e20 > e50 && close > e20 && m.hist > 0 && m.hist > m.histPrev && roc > 0)
      return { action: "KAUF", reason: `Aufwärtstrend: EMA 20 über EMA 50, Kurs über EMA 20, MACD-Momentum steigt, ROC +${r2(roc)} %.`,
        signals: s, stopLoss: close - ctx.cfg.slAtr * atr, takeProfit: close + ctx.cfg.tpAtr * atr };
    return hold(e20 > e50 ? "Trend positiv, aber Momentum nicht bestätigt." : "Kein Aufwärtstrend (EMA 20 unter EMA 50).", s);
  },

  meanrev(ctx) {
    const { closes, close, atr } = base(ctx);
    const mid = sma(closes, 20), sd = stdev(closes, 20);
    const z = (close - mid) / sd, r = rsi(closes);
    const s = { rsi14: r2(r), zScore: r2(z), sma20: r2(mid), lowerBand: r2(mid - 2 * sd) };
    if (ctx.hasPosition) {
      if (close >= mid) return { action: "VERKAUF", reason: "Kurs hat den Mittelwert (SMA 20) erreicht.", signals: s };
      return hold("Rückkehr zum Mittelwert noch nicht erreicht.", s);
    }
    if (r < 30 && z < -2)
      return { action: "KAUF", reason: `Starke Übertreibung nach unten: RSI ${r2(r)}, Z-Score ${r2(z)} (unter dem unteren Bollinger-Band).`,
        signals: s, stopLoss: close - ctx.cfg.slAtr * atr, takeProfit: Math.min(mid, close + ctx.cfg.tpAtr * atr) };
    return hold("Keine ausreichende Übertreibung (RSI ≥ 30 oder Z-Score ≥ -2).", s);
  },

  breakout(ctx) {
    const { closes, close, atr, atrS } = base(ctx);
    const n = ctx.cfg.lookback ?? 48;
    const prior = ctx.candles.slice(-n - 1, -1);
    const level = Math.max(...prior.map((c) => c.h));
    const vol = lastOf(ctx.candles).v, avgVol = mean(ctx.candles.slice(-21, -1).map((c) => c.v));
    const volRatio = vol / avgVol;
    const atrRising = atr > atrS[atrS.length - 6];
    const s = { breakoutLevel: r2(level), close: r2(close), volumeRatio: r2(volRatio), atrRising };
    if (ctx.hasPosition) {
      if (close < level - atr) return { action: "VERKAUF", reason: "Fehlausbruch: Kurs deutlich zurück unter das Ausbruchsniveau.", signals: s };
      return hold("Ausbruch hält.", s);
    }
    if (close > level && volRatio >= 1.8 && atrRising)
      return { action: "KAUF", reason: `Ausbruch über das ${n}-Kerzen-Hoch (${r2(level)} €) mit ${r2(volRatio, 1)}-fachem Volumen.`,
        signals: s, stopLoss: level - ctx.cfg.slAtr * atr, takeProfit: close + ctx.cfg.tpAtr * atr };
    return hold(close > level ? "Kurs über dem Hoch, aber Volumen oder Volatilität bestätigt nicht." : "Kein Ausbruch.", s);
  },

  multi(ctx) {
    const { closes, close, atr } = base(ctx);
    const e20 = lastOf(emaSeries(closes, 20)), e50 = lastOf(emaSeries(closes, 50));
    const r = rsi(closes), m = macd(closes), obv = obvSlope(ctx.candles);
    const atrPct = (atr / close) * 100;
    const mid = sma(closes, 20), sd = stdev(closes, 20), bbPos = (close - (mid - 2 * sd)) / (4 * sd);
    const points = {
      trend: e20 > e50 && close > e20,
      momentum: r > 50 && r < 70 && m.hist > 0,
      volumen: obv > 0,
      volatilitaet: atrPct > 0.15 && atrPct < 2.5,
      bollinger: bbPos > 0.5 && bbPos < 0.95,
    };
    const score = Object.values(points).filter(Boolean).length;
    const s = { score, ...points, rsi14: r2(r), atrPct: r2(atrPct), bbPosition: r2(bbPos) };
    if (ctx.hasPosition) {
      if (score <= 1) return { action: "VERKAUF", reason: `Signalqualität gefallen (${score}/5 Punkte).`, signals: s };
      return hold(`Position gehalten (${score}/5 Punkte).`, s);
    }
    if (score >= 4)
      return { action: "KAUF", reason: `${score} von 5 Signalen positiv: ${Object.entries(points).filter(([, v]) => v).map(([k]) => k).join(", ")}.`,
        signals: s, stopLoss: close - ctx.cfg.slAtr * atr, takeProfit: close + ctx.cfg.tpAtr * atr };
    return hold(`Nur ${score}/5 Signale positiv – mindestens 4 nötig.`, s);
  },

  aggressive(ctx) {
    const { closes, close, atr } = base(ctx);
    const f = emaSeries(closes, 9), sl = emaSeries(closes, 21);
    const crossUp = lastOf(f) > lastOf(sl) && f[f.length - 2] <= sl[sl.length - 2];
    const r = rsi(closes);
    const volRatio = lastOf(ctx.candles).v / mean(ctx.candles.slice(-21, -1).map((c) => c.v));
    const s = { ema9: r2(lastOf(f)), ema21: r2(lastOf(sl)), crossUp, rsi14: r2(r), volumeRatio: r2(volRatio) };
    if (ctx.hasPosition) {
      if (lastOf(f) < lastOf(sl)) return { action: "VERKAUF", reason: "EMA 9 unter EMA 21 – kurzfristiges Momentum weg.", signals: s };
      return hold("Momentum intakt.", s);
    }
    if (crossUp && r > 55 && volRatio > 1.3)
      return { action: "KAUF", reason: `EMA 9 kreuzt EMA 21 nach oben, RSI ${r2(r)}, Volumen ${r2(volRatio, 1)}-fach.`,
        signals: s, stopLoss: close - ctx.cfg.slAtr * atr, takeProfit: close + ctx.cfg.tpAtr * atr };
    return hold("Kein bestätigtes Kurzfrist-Signal.", s);
  },
};

// ======================= Ausführungs-Simulation =======================
interface Fill { qty: number; avgPrice: number; notional: number; fee: number; spreadPct: number; slippagePct: number; complete: boolean }

/** Läuft das Orderbuch ab, wie es zum Entscheidungszeitpunkt vorliegt. */
function simulate(book: OrderBook, side: "KAUF" | "VERKAUF", amount: { eur?: number; qty?: number }): Fill {
  const levels = side === "KAUF" ? book.asks : book.bids;
  const best = levels[0].price;
  const mid = (book.asks[0].price + book.bids[0].price) / 2;
  const maxQty = levels.reduce((s, l) => s + l.qty, 0) * MAX_BOOK_SHARE;
  let qty = 0, cost = 0;
  for (const l of levels) {
    let take = l.qty;
    if (amount.eur !== undefined) take = Math.min(take, (amount.eur - cost) / l.price);
    if (amount.qty !== undefined) take = Math.min(take, amount.qty - qty);
    take = Math.min(take, maxQty - qty);
    if (take <= 0) break;
    qty += take; cost += take * l.price;
  }
  const raw = qty > 0 ? cost / qty : best;
  const avgPrice = side === "KAUF" ? raw * (1 + LATENCY_SLIPPAGE) : raw * (1 - LATENCY_SLIPPAGE);
  const notional = qty * avgPrice;
  const wanted = amount.qty ?? (amount.eur! / best);
  return {
    qty, avgPrice, notional, fee: notional * FEE_RATE,
    spreadPct: (book.asks[0].price - book.bids[0].price) / mid,
    slippagePct: Math.abs(avgPrice - best) / best,
    complete: qty >= wanted * 0.999,
  };
}

// ======================= Engine =======================
type DB = SupabaseClient;

async function logError(db: DB, source: string, err: unknown, context: Record<string, unknown> = {}) {
  const message = err instanceof Error ? err.message : String(err);
  console.error(source, message);
  await db.from("pt_error_logs").insert({ source, message, context });
}

async function sell(db: DB, bot: any, pos: any, book: OrderBook, asset: string, reason: string, signals: Record<string, unknown>) {
  const f = simulate(book, "VERKAUF", { qty: Number(pos.qty) });
  if (f.qty <= 0) throw new Error(`Keine Liquidität für Verkauf ${asset}`);
  const share = f.qty / Number(pos.qty);
  const basis = Number(pos.cost_basis) * share;
  const proceeds = f.notional - f.fee;
  const pnl = proceeds - basis;
  bot.cash = Number(bot.cash) + proceeds;
  await db.from("pt_trades").insert({
    bot_id: bot.id, position_id: pos.id, asset, side: "VERKAUF", price: f.avgPrice, qty: f.qty, notional: f.notional,
    fee: f.fee, spread_pct: f.spreadPct, slippage_pct: f.slippagePct, stop_loss: pos.stop_loss, take_profit: pos.take_profit,
    reason: f.complete ? reason : `${reason} (Teilausführung wegen begrenzter Liquidität)`, signals, pnl_eur: pnl, pnl_pct: pnl / basis,
  });
  if (f.complete) {
    await db.from("pt_positions").update({ status: "CLOSED", closed_at: new Date().toISOString() }).eq("id", pos.id);
  } else {
    await db.from("pt_positions").update({ qty: Number(pos.qty) - f.qty, cost_basis: Number(pos.cost_basis) - basis }).eq("id", pos.id);
  }
  // Verlustserie für Abkühlphase (Aggressiv) – verkleinert nie das Risiko-Limit, sondern pausiert Einstiege
  const st = bot.state ?? {};
  st.lossStreak = pnl < 0 ? (st.lossStreak ?? 0) + 1 : 0;
  if (bot.config.cooldownAfterLosses && st.lossStreak >= bot.config.cooldownAfterLosses) {
    st.cooldownUntil = Date.now() + bot.config.cooldownMinutes * 60_000;
    st.lossStreak = 0;
  }
  bot.state = st;
  return pnl;
}

Deno.serve(async (req) => {
  const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const { data: sec } = await db.from("pt_secrets").select("value").eq("key", "cron").maybeSingle();
  if (!sec?.value || req.headers.get("x-cron-secret") !== sec.value) return new Response("Nicht autorisiert", { status: 401 });
  const now = new Date();

  // Lock gegen überlappende Läufe
  const { data: lock } = await db.from("pt_engine_status")
    .update({ locked_until: new Date(now.getTime() + 55_000).toISOString(), last_run: now.toISOString() })
    .eq("id", 1).or(`locked_until.is.null,locked_until.lt.${now.toISOString()}`).select();
  if (!lock?.length) return new Response("Läuft bereits", { status: 200 });

  try {
    // ---- 1. Marktdaten laden (nur geschlossene Kerzen + aktuelles Orderbuch) ----
    const { data: bots } = await db.from("pt_bots").select("*").order("id");
    const intervals: number[] = [...new Set<number>(bots!.map((b: any) => Number(b.config.interval)))];
    const candles: Record<string, Candle[]> = {};
    const books: Record<string, OrderBook> = {};
    for (const a of ASSETS) {
      try {
        books[a.symbol] = await provider.getOrderBook(a.pair, 50);
        for (const iv of intervals) candles[`${a.symbol}|${iv}`] = (await provider.getClosedCandles(a.pair, iv)).slice(-CANDLES_NEEDED);
        const b = books[a.symbol], bid = b.bids[0].price, ask = b.asks[0].price, mid = (bid + ask) / 2;
        await db.from("pt_market_snapshots").insert({
          source: provider.name, asset: a.symbol, bid, ask, mid, spread_pct: (ask - bid) / mid,
          bid_depth_eur: b.bids.reduce((s, l) => s + l.price * l.qty, 0),
          ask_depth_eur: b.asks.reduce((s, l) => s + l.price * l.qty, 0),
          last_closed_candle: new Date(lastOf(candles[`${a.symbol}|${intervals[0]}`]).t).toISOString(),
        });
      } catch (e) { await logError(db, "marktdaten", e, { asset: a.symbol }); }
    }

    // ---- 2. Jeder Bot unabhängig ----
    for (const bot of bots as any[]) {
      try {
        const cfg = bot.config;
        const { data: open } = await db.from("pt_positions").select("*").eq("bot_id", bot.id).eq("status", "OPEN");
        let positions = open ?? [];
        bot.state = bot.state ?? {};
        bot.state.lastEval = bot.state.lastEval ?? {};

        for (const a of ASSETS) {
          const book = books[a.symbol];
          const cs = candles[`${a.symbol}|${cfg.interval}`];
          if (!book || !cs || cs.length < 60) continue;
          const pos = positions.find((p: any) => p.asset === a.symbol);
          const bestBid = book.bids[0].price;

          // a) Stop-Loss / Take-Profit jede Minute gegen den aktuellen Geldkurs (ausgeführt zum Marktpreis, nicht zum Wunschpreis)
          if (pos) {
            if (bestBid <= Number(pos.stop_loss)) {
              await sell(db, bot, pos, book, a.symbol, `Stop-Loss ausgelöst (Geldkurs ${r2(bestBid)} € ≤ ${r2(Number(pos.stop_loss))} €).`, { bestBid });
              positions = positions.filter((p: any) => p.id !== pos.id); continue;
            }
            if (bestBid >= Number(pos.take_profit)) {
              await sell(db, bot, pos, book, a.symbol, `Take-Profit erreicht (Geldkurs ${r2(bestBid)} € ≥ ${r2(Number(pos.take_profit))} €).`, { bestBid });
              positions = positions.filter((p: any) => p.id !== pos.id); continue;
            }
          }

          // b) Strategie nur einmal pro neu geschlossener Kerze
          const candleT = lastOf(cs).t;
          if (bot.state.lastEval[a.symbol] === candleT) continue;
          bot.state.lastEval[a.symbol] = candleT;
          const candleIso = new Date(candleT).toISOString();

          const sig = strategies[bot.strategy]({ candles: cs, cfg, hasPosition: !!pos });

          if (sig.action === "VERKAUF" && pos) {
            await sell(db, bot, pos, book, a.symbol, sig.reason, sig.signals);
            positions = positions.filter((p: any) => p.id !== pos.id);
            await db.from("pt_decisions").insert({ bot_id: bot.id, asset: a.symbol, action: "VERKAUF", reason: sig.reason, signals: sig.signals, candle_time: candleIso });
            continue;
          }

          if (sig.action === "KAUF" && !pos) {
            const block = (why: string) => db.from("pt_decisions").insert({ bot_id: bot.id, asset: a.symbol, action: "BLOCKIERT", reason: `Kaufsignal, aber: ${why}`, signals: sig.signals, candle_time: candleIso });
            if (bot.status !== "AKTIV") { await block("Bot ist pausiert."); continue; }
            if (positions.length >= cfg.maxOpenPositions) { await block("maximale Anzahl offener Positionen erreicht."); continue; }
            if (bot.state.cooldownUntil && Date.now() < bot.state.cooldownUntil) { await block("Abkühlphase nach Verlustserie."); continue; }

            // Positionsgröße: festes Risiko in % des AKTUELLEN Kontowerts -> nach Verlusten automatisch kleiner (kein Martingale)
            const entryRef = book.asks[0].price;
            const stopDist = (entryRef - sig.stopLoss!) / entryRef;
            if (!(stopDist > 0)) { await block("ungültiger Stop-Loss."); continue; }
            const equity = Number(bot.equity);
            const riskEur = equity * cfg.riskPerTrade;
            const notionalTarget = Math.min(riskEur / (stopDist + 2 * FEE_RATE), equity * cfg.maxPositionPct, (Number(bot.cash) / (1 + FEE_RATE)) * 0.995);
            if (notionalTarget < MIN_ORDER_EUR) { await block(`Positionsgröße ${r2(notionalTarget)} € unter Mindestorder.`); continue; }

            const f = simulate(book, "KAUF", { eur: notionalTarget });
            if (f.notional + f.fee > Number(bot.cash)) { await block("nicht genug virtuelles Guthaben."); continue; }
            bot.cash = Number(bot.cash) - f.notional - f.fee;
            const { data: np } = await db.from("pt_positions").insert({
              bot_id: bot.id, asset: a.symbol, qty: f.qty, entry_price: f.avgPrice, cost_basis: f.notional + f.fee,
              stop_loss: sig.stopLoss, take_profit: sig.takeProfit,
            }).select().single();
            positions.push(np);
            await db.from("pt_trades").insert({
              bot_id: bot.id, position_id: np.id, asset: a.symbol, side: "KAUF", price: f.avgPrice, qty: f.qty, notional: f.notional,
              fee: f.fee, spread_pct: f.spreadPct, slippage_pct: f.slippagePct, stop_loss: sig.stopLoss, take_profit: sig.takeProfit,
              reason: sig.reason, signals: { ...sig.signals, riskEur: r2(riskEur), stopDistPct: r2(stopDist * 100) },
            });
            await db.from("pt_decisions").insert({ bot_id: bot.id, asset: a.symbol, action: "KAUF", reason: sig.reason, signals: sig.signals, candle_time: candleIso });
            continue;
          }

          await db.from("pt_decisions").insert({ bot_id: bot.id, asset: a.symbol, action: "HALTEN", reason: sig.reason, signals: sig.signals, candle_time: candleIso });
        }

        // ---- 3. Bewertung, Drawdown, Verlustschutz ----
        const valueOf = (p: any) => Number(p.qty) * (books[p.asset]?.bids[0].price ?? Number(p.entry_price));
        let posValue = positions.reduce((s: number, p: any) => s + valueOf(p), 0);
        let equity = Number(bot.cash) + posValue;
        const peak = Math.max(Number(bot.peak_equity), equity);
        const dd = (peak - equity) / peak;
        let status = bot.status, pausedReason = bot.paused_reason;

        if (status === "AKTIV" && equity <= Number(bot.start_capital) * (1 - cfg.maxLossPct)) {
          status = "PAUSIERT";
          pausedReason = `Verlustlimit von ${cfg.maxLossPct * 100} % erreicht am ${now.toISOString()}. Alle Positionen geschlossen.`;
          for (const p of positions) {
            if (books[p.asset]) await sell(db, bot, p, books[p.asset], p.asset, "Verlustlimit erreicht – Notverkauf.", {});
          }
          positions = []; posValue = 0; equity = Number(bot.cash);
        }

        await db.from("pt_bots").update({
          cash: bot.cash, equity, positions_value: posValue, peak_equity: peak,
          max_drawdown: Math.max(Number(bot.max_drawdown), dd), status, paused_reason: pausedReason,
          state: bot.state, updated_at: now.toISOString(),
        }).eq("id", bot.id);

        if (now.getUTCMinutes() % 15 === 0)
          await db.from("pt_equity_history").insert({ bot_id: bot.id, equity, cash: bot.cash, positions_value: posValue, drawdown: dd });
      } catch (e) { await logError(db, `bot:${bot.id}`, e); }
    }

    await db.from("pt_engine_status").update({ last_success: now.toISOString(), locked_until: null, last_error: null }).eq("id", 1);
    return new Response("ok");
  } catch (e) {
    await logError(db, "engine", e);
    await db.from("pt_engine_status").update({ locked_until: null, last_error: String(e) }).eq("id", 1);
    return new Response("Fehler", { status: 500 });
  }
});
