-- Ruft die Trading-Engine jede Minute serverseitig auf – unabhängig davon, ob Handy oder PC an sind.
-- VOR dem Ausführen ersetzen: <PROJECT_REF> und <CRON_SECRET> (gleicher Wert wie das Secret der Edge Function).

create extension if not exists pg_cron;
create extension if not exists pg_net;

select cron.unschedule('paper-trading-engine') where exists (select 1 from cron.job where jobname = 'paper-trading-engine');

select cron.schedule(
  'paper-trading-engine',
  '* * * * *',
  $$
  select net.http_post(
    url     := 'https://<PROJECT_REF>.supabase.co/functions/v1/trading-engine',
    headers := jsonb_build_object('Content-Type','application/json','x-cron-secret','<CRON_SECRET>'),
    body    := '{}'::jsonb,
    timeout_milliseconds := 50000
  );
  $$
);

-- Aufräumen: Markt-Snapshots und HALTEN-Entscheidungen älter als 30 Tage löschen (täglich 03:00 UTC)
select cron.unschedule('paper-trading-cleanup') where exists (select 1 from cron.job where jobname = 'paper-trading-cleanup');
select cron.schedule('paper-trading-cleanup', '0 3 * * *', $$
  delete from market_snapshots where ts < now() - interval '30 days';
  delete from decisions where action = 'HALTEN' and ts < now() - interval '30 days';
$$);
