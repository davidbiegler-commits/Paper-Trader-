-- Paper-Trading: Datenbankschema (Supabase / Postgres)
-- Ausschließlich virtuelles Geld. Keine Broker-Anbindung.



-- Geheimnis für den Cron-Aufruf (keine öffentliche Policy -> nur serverseitig lesbar)
create table if not exists pt_secrets (key text primary key, value text not null);
alter table pt_secrets enable row level security;
insert into pt_secrets values ('cron', replace(gen_random_uuid()::text || gen_random_uuid()::text, '-', '')) on conflict do nothing;

-- ---------- Bots & Kontostände ----------
create table if not exists pt_bots (
  id              text primary key,
  name            text not null,
  strategy        text not null,
  description     text not null,
  start_capital   numeric not null default 100,
  cash            numeric not null default 100,
  equity          numeric not null default 100,   -- Cash + Marktwert offener Positionen (Bid-Seite)
  positions_value numeric not null default 0,
  peak_equity     numeric not null default 100,   -- bestes bisheriges Ergebnis
  max_drawdown    numeric not null default 0,     -- 0.12 = 12 %
  status          text not null default 'AKTIV' check (status in ('AKTIV','PAUSIERT')),
  paused_reason   text,
  config          jsonb not null,                 -- Risikoparameter & Intervall
  state           jsonb not null default '{}'::jsonb,
  started_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

-- ---------- Positionen ----------
create table if not exists pt_positions (
  id           uuid primary key default gen_random_uuid(),
  bot_id       text not null references pt_bots(id),
  asset        text not null,
  qty          numeric not null,
  entry_price  numeric not null,        -- durchschnittlicher Ausführungskurs inkl. Slippage
  cost_basis   numeric not null,        -- Einsatz inkl. Kaufgebühr
  stop_loss    numeric not null,
  take_profit  numeric not null,
  status       text not null default 'OPEN' check (status in ('OPEN','CLOSED')),
  opened_at    timestamptz not null default now(),
  closed_at    timestamptz
);
create index if not exists positions_bot_open on pt_positions(bot_id) where status = 'OPEN';

-- ---------- Trades ----------
create table if not exists pt_trades (
  id            uuid primary key default gen_random_uuid(),
  bot_id        text not null references pt_bots(id),
  position_id   uuid references pt_positions(id),
  asset         text not null,
  side          text not null check (side in ('KAUF','VERKAUF')),
  executed_at   timestamptz not null default now(),
  price         numeric not null,       -- durchschnittlicher Ausführungskurs
  qty           numeric not null,
  notional      numeric not null,       -- Kurs * Menge
  fee           numeric not null,
  spread_pct    numeric,                -- Spread zum Entscheidungszeitpunkt
  slippage_pct  numeric,                -- Abweichung vom besten Kurs
  stop_loss     numeric,
  take_profit   numeric,
  reason        text not null,
  signals       jsonb not null default '{}'::jsonb,
  pnl_eur       numeric,                -- nur bei Verkauf
  pnl_pct       numeric
);
create index if not exists trades_bot_time on pt_trades(bot_id, executed_at desc);

-- ---------- Markt-Snapshots ----------
create table if not exists pt_market_snapshots (
  id          bigint generated always as identity primary key,
  ts          timestamptz not null default now(),
  source      text not null,
  asset       text not null,
  bid         numeric not null,
  ask         numeric not null,
  mid         numeric not null,
  spread_pct  numeric not null,
  bid_depth_eur numeric,
  ask_depth_eur numeric,
  last_closed_candle timestamptz
);
create index if not exists snapshots_asset_time on pt_market_snapshots(asset, ts desc);

create or replace view pt_latest_prices with (security_invoker = true) as
  select distinct on (asset) asset, ts, source, bid, ask, mid, spread_pct, last_closed_candle
  from pt_market_snapshots order by asset, ts desc;

-- ---------- Performance-Historie ----------
create table if not exists pt_equity_history (
  id              bigint generated always as identity primary key,
  bot_id          text not null references pt_bots(id),
  ts              timestamptz not null default now(),
  equity          numeric not null,
  cash            numeric not null,
  positions_value numeric not null,
  drawdown        numeric not null
);
create index if not exists equity_bot_time on pt_equity_history(bot_id, ts);

-- ---------- Entscheidungen (inkl. HOLD) ----------
create table if not exists pt_decisions (
  id       bigint generated always as identity primary key,
  bot_id   text not null references pt_bots(id),
  ts       timestamptz not null default now(),
  asset    text not null,
  action   text not null check (action in ('KAUF','VERKAUF','HALTEN','BLOCKIERT')),
  reason   text not null,
  signals  jsonb not null default '{}'::jsonb,
  candle_time timestamptz
);
create index if not exists decisions_time on pt_decisions(ts desc);

-- ---------- Fehlerprotokoll ----------
create table if not exists pt_error_logs (
  id       bigint generated always as identity primary key,
  ts       timestamptz not null default now(),
  source   text not null,
  message  text not null,
  context  jsonb
);

-- ---------- Engine-Status (Lock + Heartbeat) ----------
create table if not exists pt_engine_status (
  id            int primary key default 1 check (id = 1),
  last_run      timestamptz,
  last_success  timestamptz,
  locked_until  timestamptz,
  last_error    text
);
insert into pt_engine_status (id) values (1) on conflict do nothing;

-- ---------- Row Level Security: Frontend darf NUR lesen ----------
do $$
declare t text;
begin
  foreach t in array array['pt_bots','pt_positions','pt_trades','pt_market_snapshots','pt_equity_history','pt_decisions','pt_error_logs','pt_engine_status']
  loop
    execute format('alter table %I enable row level security', t);
    execute format('drop policy if exists "public read" on %I', t);
    execute format('create policy "public read" on %I for select to anon, authenticated using (true)', t);
  end loop;
end $$;
-- Schreibzugriff hat nur die Edge Function über den Service-Role-Key (umgeht RLS, liegt nur serverseitig).

-- ---------- Die 5 Bots ----------
-- riskPerTrade: Anteil des aktuellen Kontowerts, der pro Trade bis zum Stop-Loss riskiert wird
-- maxPositionPct: max. Anteil des Kontowerts in einer Position
-- maxLossPct: Verlustlimit bezogen auf das Startkapital -> Bot wird pausiert
insert into pt_bots (id, name, strategy, description, config) values
('trend', 'Trend', 'trend',
 'EMA 20/50, Kursposition, MACD-Momentum und Rate of Change auf 15-Minuten-Kerzen.',
 '{"interval":15,"riskPerTrade":0.01,"maxPositionPct":0.5,"maxOpenPositions":2,"maxLossPct":0.25,"slAtr":2.0,"tpAtr":3.5}'),
('meanrev', 'Mean Reversion', 'meanrev',
 'Sucht Überverkauf: RSI < 30, Kurs unter dem unteren Bollinger-Band, Z-Score < -2. Ziel: Rückkehr zum Mittelwert.',
 '{"interval":15,"riskPerTrade":0.01,"maxPositionPct":0.5,"maxOpenPositions":2,"maxLossPct":0.25,"slAtr":1.5,"tpAtr":2.5}'),
('breakout', 'Breakout', 'breakout',
 'Schlusskurs über dem 48-Kerzen-Hoch mit mindestens 1,8-fachem Durchschnittsvolumen und steigender Volatilität.',
 '{"interval":15,"riskPerTrade":0.01,"maxPositionPct":0.5,"maxOpenPositions":2,"maxLossPct":0.25,"slAtr":0.5,"tpAtr":3.0,"lookback":48}'),
('multi', 'Multi-Signal', 'multi',
 'Punktesystem aus Trend, Momentum, Volumen (OBV), Volatilität (ATR %) und Bollinger-Position. Kauf ab 4 von 5 Punkten.',
 '{"interval":15,"riskPerTrade":0.012,"maxPositionPct":0.5,"maxOpenPositions":2,"maxLossPct":0.25,"slAtr":2.0,"tpAtr":3.0}'),
('aggressive', 'Aggressiv', 'aggressive',
 '5-Minuten-Kerzen, EMA 9/21-Kreuzung mit RSI- und Volumenbestätigung. Höheres Risiko je Trade, aber Stop-Loss, Verlustlimit und Abkühlphase nach Verlustserien.',
 '{"interval":5,"riskPerTrade":0.025,"maxPositionPct":0.8,"maxOpenPositions":1,"maxLossPct":0.35,"slAtr":1.2,"tpAtr":2.0,"cooldownAfterLosses":2,"cooldownMinutes":60}')
on conflict (id) do nothing;
